<?php

$GLOBALS['CLASSPATH']=dirname(__FILE__) . "/../classes";

