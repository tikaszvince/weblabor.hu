<?php

namespace PHP\Lang;

require_once($GLOBALS['CLASSPATH'] . '/PHP/IO/Serializable.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/Exception.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/IO/NotSerializableException.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/Object.php');

/**
 * Test exception for PHP\Lang\ExceptionTest
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 * @see \PHP\Lang\Exception
 */
class ExceptionTestException1 extends Exception
{
}

/**
 * Test exception for PHP\Lang\ExceptionTest
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 * @see \PHP\Lang\Exception
 */
class ExceptionTestException2 extends Exception
{
}

/**
 * Test of the \PHP\Lang\Exception class
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
class ExceptionTest extends \PHPUnit_Framework_TestCase
{
	/**
	 * @expectedException \PHP\Lang\Exception
	 */
	function testThrow()
	{
		throw new ExceptionTestException1();
	}

	/**
	 * Tests the \PHP\Lang\Exception::hashCode() function
	 */
	public function testHashCode()
	{
		$object1 = new ExceptionTestException1();
		$object2 = new ExceptionTestException2();
		$this->assertType("int", $object1->hashCode(), "Hashcode is not int!");
		$this->assertGreaterThan(0, $object1->hashCode(), "Hashcode is not larger that 0!");
		$this->assertEquals($object1->hashCode(), $object1->hashCode(), "Hashcode differs in two consecutive runs!");
		$this->assertNotEquals($object1->hashCode(), $object2->hashCode(), "Two object have the same hashcode!");
	}

	/**
	 * Tests the \PHP\Lang\Exception::className() function
	 */
	public function testClassName()
	{
		$object = new ExceptionTestException1();
		$this->assertType("string", $object->className(), "Class name is not a string!");
		$this->assertEquals("PHP\Lang\ExceptionTestException1", $object->className(), "Class name does not return correctly!");
	}

	/**
	 * Tests the \PHP\Lang\Exception::equals() function
	 */
	public function testEquals()
	{
		$object1 = new ExceptionTestException1();
		$object2 = new ExceptionTestException2();
		$this->assertType("bool", $object1->equals($object1), "Object equals does not return a boolean!");
		$this->assertEquals(true, $object1->equals($object1), "Object does not equal with itself!");
		$this->assertEquals(false, $object1->equals($object2), "Object does equal with a different object!");
	}

	/**
	 * Tests the \PHP\Lang\Exception::isSubclass() function
	 * @see \PHP\Lang\Exception::__isSubclass
	 */
	public function testSubclass()
	{
		$object1 = new ExceptionTestException1();
		$object2 = new ExceptionTestException2();
		$this->assertType("bool", $object1->isSubclass("PHP\Lang\Exception"), "Is subclass failed to return a bool!");
		$this->assertEquals(true, $object1->isSubclass("PHP\Lang\Exception"), "Object is not a subclass of PHP\Lang\Object");
		$this->assertEquals(false, $object1->isSubclass($object2), "Test object 1 sais it's a subclass of object 2 where it shouldn't be!");
	}

	/**
	 * Tests the \PHP\Lang\Exception::isSubclass() function
	 * @see \PHP\Lang\Exception::__isInstance
	 */
	public function testInstance()
	{
		$object1 = new ExceptionTestException1();
		$object2 = new ExceptionTestException2();
		$this->assertType("bool", $object1->isInstance("PHP\Lang\Exception"), "Is instance failed to return a bool!");
		$this->assertEquals(true, $object1->isInstance("PHP\Lang\Exception"), "Object is not an instance of PHP\Lang\Object");
		$this->assertEquals(false, $object1->isInstance($object2), "Test object 1 sais it's a subclass of object 2 where it shouldn't be!");
		$this->assertEquals(true, $object2->isInstance("PHP\IO\Serializable"), "Test object 2 should be an instance of PHP\IO\Serializable!");
	}

	/**
	 * Tests, if the __sleep method properly works if Serializable
	 * @see \PHP\Lang\Exception::__sleep
	 * @depends testThrow
	 */
	public function testSerializableSleep()
	{
		$object = new ExceptionTestException2();
		$object->__sleep();
	}

	/**
	 * Tests, if the __wakeup method properly works if Serializable
	 * @see \PHP\Lang\Exception::__wakeup
	 * @depends testThrow
	 */
	public function testSerializableWakeup()
	{
		$object = new ExceptionTestException2();
		$object->__wakeup();
	}
}
