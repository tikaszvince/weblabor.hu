<?php

namespace PHP\Lang;

require_once($GLOBALS['CLASSPATH'] . '/PHP/IO/Serializable.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/Clonable.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/Exception.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/IO/NotSerializableException.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/CloneNotSupportedException.php');
require_once($GLOBALS['CLASSPATH'] . '/PHP/Lang/Object.php');

/**
 * Test object 1 for JZ_ObjectTest
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
class ObjectTestObject1 extends Object
{
}

/**
 * Test object 2 for JZ_ObjectTest
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
class ObjectTestObject2 extends Object implements \PHP\IO\Serializable, Clonable
{
}

/**
 * Test of the JZ_Object class
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 * @see \PHP\Lang\Object
 */
class ObjectTest extends \PHPUnit_Framework_TestCase
{
	/**
	 * Tests the \PHP\Lang\Object::hashCode() function
	 */
	public function testHashCode()
	{
		$object1 = new ObjectTestObject1();
		$object2 = new ObjectTestObject2();
		$this->assertType("int", $object1->hashCode(), "Hashcode is not int!");
		$this->assertGreaterThan(0, $object1->hashCode(), "Hashcode is not larger that 0!");
		$this->assertEquals($object1->hashCode(), $object1->hashCode(), "Hashcode differs in two consecutive runs!");
		$this->assertNotEquals($object1->hashCode(), $object2->hashCode(), "Two object have the same hashcode!");
	}
	
	/**
	 * Tests the \PHP\Lang\Object::className() function
	 */
	public function testClassName()
	{
		$object = new ObjectTestObject1();
		$this->assertType("string", $object->className(), "Class name is not a string!");
		$this->assertEquals("PHP\Lang\ObjectTestObject1", $object->className(), "Class name does not return correctly!");
	}

	/**
	 * Tests the \PHP\Lang\Object::equals() function
	 */
	public function testEquals()
	{
		$object1 = new ObjectTestObject1();
		$object2 = new ObjectTestObject2();
		$this->assertType("bool", $object1->equals($object1), "Object equals does not return a boolean!");
		$this->assertEquals(true, $object1->equals($object1), "Object does not equal with itself!");
		$this->assertEquals(false, $object1->equals($object2), "Object does equal with a different object!");
	}
	
	/**
	 * Tests the \PHP\Lang\Object::isSubclass() function
	 * @see \PHP\Lang\Object::__isSubclass
	 */
	public function testSubclass()
	{
		$object1 = new ObjectTestObject1();
		$object2 = new ObjectTestObject2();
		$this->assertType("bool", $object1->isSubclass("PHP\Lang\Object"), "Is subclass failed to return a bool!");
		$this->assertEquals(true, $object1->isSubclass("PHP\Lang\Object"), "Object is not a subclass of PHP\Lang\Object");
		$this->assertEquals(false, $object1->isSubclass($object2), "Test object 1 sais it's a subclass of object 2 where it shouldn't be!");
		$this->assertEquals(false, $object2->isSubclass("PHP\IO\Serializable"), "Test object 2 should not be a subclass of PHP\IO\Serializable!");
	}

	/**
	 * Tests the \PHP\Lang\Object::isSubclass() function
	 * @see \PHP\Lang\Object::__isInstance
	 */
	public function testInstance()
	{
		$object1 = new ObjectTestObject1();
		$object2 = new ObjectTestObject2();
		$this->assertType("bool", $object1->isInstance("PHP\Lang\Object"), "Is instance failed to return a bool!");
		$this->assertEquals(true, $object1->isInstance("PHP\Lang\Object"), "Object is not an instance of PHP\Lang\Object");
		$this->assertEquals(false, $object1->isInstance($object2), "Test object 1 sais it's a subclass of object 2 where it shouldn't be!");
		$this->assertEquals(false, $object1->isInstance("PHP\IO\Serializable"), "Test object 1 should not be an instance of PHP\IO\Serializable!");
		$this->assertEquals(true, $object2->isInstance("PHP\IO\Serializable"), "Test object 2 should be an instance of PHP\IO\Serializable!");
	}

	/**
	 * Tests if object throws \PHP\IO\NotSerializableException uppon
	 * serialization.
	 * @expectedException \PHP\IO\NotSerializableException
	 * @see \PHP\Lang\Object::__sleep
	 * @see \PHP\Lang\Object::__wakeup
	 */
	public function testSerialization()
	{
		$object = new ObjectTestObject1();
		serialize($object);
		$this->fail();
	}

	/**
	 * Tests, if the __clone method properly throws an exception
	 * @expectedException \PHP\Lang\CloneNotSupportedException
	 * @see \PHP\Lang\Object::__clone
	 */
	public function testClone()
	{
		$object = new ObjectTestObject1();
		clone $object;
	}

	/**
	 * Tests, if the __clone method properly works if the class is Clonable
	 * @see \PHP\Lang\Object::__clone
	 */
	public function testClonableClone()
	{
		$object = new ObjectTestObject2();
		clone $object;
	}

	/**
	 * Tests, if the __sleep method properly throws an exception
	 * @expectedException \PHP\IO\NotSerializableException
	 * @see \PHP\Lang\Object::__sleep
	 */
	public function testSleep()
	{
		$object = new ObjectTestObject1();
		$object->__sleep();
	}

	/**
	 * Tests, if the __wakeup method properly throws an exception
	 * @expectedException \PHP\IO\NotSerializableException
	 * @see \PHP\Lang\Object::__wakeup
	 */
	public function testWakeup()
	{
		$object = new ObjectTestObject1();
		$object->__wakeup();
	}

	/**
	 * Tests, if the __sleep method properly works if Serializable
	 * @see \PHP\Lang\Object::__sleep
	 */
	public function testSerializableSleep()
	{
		$object = new ObjectTestObject2();
		$object->__sleep();
	}

	/**
	 * Tests, if the __wakeup method properly works if Serializable
	 * @see \PHP\Lang\Object::__wakeup
	 */
	public function testSerializableWakeup()
	{
		$object = new ObjectTestObject2();
		$object->__wakeup();
	}
}