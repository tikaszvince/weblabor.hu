<?php

namespace PHP\IO;

/**
 * This exception is thrown if a class does not imlement the PHP\IO\Serializable
 * interface
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
class NotSerializableException extends \PHP\Lang\Exception
{
    function __construct($classname)
    {
	parent::__construct("Class " . $classname . " is not serializable!");
    }
}

?>
