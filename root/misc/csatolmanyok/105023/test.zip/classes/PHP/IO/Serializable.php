<?php

namespace PHP\IO;

/**
 * States that the class implementing this is ready for serialization.
 * This has NOTHING to do with PHP-s internal Serializable class.
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
interface Serializable
{
    /**
     * Method called uppon object serialization.
     */
    function __sleep();
    
    /**
     * Method called uppon object deserialization.
     */
    function __wakeup();
}

?>
