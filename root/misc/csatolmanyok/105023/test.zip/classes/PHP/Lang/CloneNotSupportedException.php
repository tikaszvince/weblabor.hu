<?php

namespace PHP\Lang;

/**
 * This exception is thrown if a class does not implement the \PHP\Lang\Clonable
 * interface.
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
class CloneNotSupportedException extends Exception
{
}

?>
