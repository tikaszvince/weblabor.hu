<?php

namespace PHP\Lang;

/**
 * This interface documents that a class is clonable.
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
interface Clonable {
}

?>
