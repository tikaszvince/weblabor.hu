<?php

namespace PHP\Lang;

/**
 * This interface provides the compareTo function.
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
interface Comparable {
	/**
	 * Compares this object with the specified object for order. Returns a
	 * negative integer, zero, or a positive integer as this object is less
	 * than, equal to, or greater than the specified object.
	 * @param Object $o
	 * @return int
	 */
	public function compareTo(Object $o);
}
?>
