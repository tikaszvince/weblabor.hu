<?php

namespace PHP\Lang;

/**
 * This is a generic exception object.
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
abstract class Exception extends \Exception implements \PHP\IO\Serializable {
	/**
	 * Stores the hash code of the current class. May be empty, use hashCode() instead!
	 * @var int
	 */
	private $hashCode;

	/**
	 * Object constructor
	 */
	public function __construct($message = "", $code = 0, Exception $previous = null) {
		parent::__construct($message, $code, $previous);
	}

	/**
	 * Object destructor
	 */
	public function __destruct() {
	}

	/**
	 * Returns the name of the current class
	 * @return string
	 */
	public final function className() {
		return get_class($this);
	}

	/**
	 * Returns a unique identifier for the current class
	 * @return int
	 */
	public function hashCode() {
		if (!$this->hashCode) {
			$this->hashCode = rand(1, getrandmax());
		}
		return $this->hashCode;
	}

	/**
	 * Compares the current class to an other
	 * @param self $object
	 * @return bool
	 */
	public function equals($object) {
		return $object == $this ? true : false;
	}

	/**
	 * Converts the current class to a string.
	 * @return unknown_type
	 */
	public function __toString() {
		return $this->className() . "@" . base_convert($this->hashCode(), 10, 16);
	}

	/**
	 * Returns if an object is a subclass of an other
	 * @param JZ_Object $class
	 * @return bool
	 */
	public function isSubclass($class) {
		return is_subclass_of($this, $class);
	}

	/**
	 * Returns if an object is an instance of a class
	 * @param string $class
	 * @return bool
	 */
	public function isInstance($class) {
		return ($this instanceof $class? true : false);
	}

	/**
	 * Method to implement serializability.
	 * @return array
	 */
	public function __sleep() {
		return array(
			"message",
			"code",
			"file",
			"line"
		);
	}

	/**
	 * Method to implement serializability.
	 */
	public function __wakeup() {
	}
}