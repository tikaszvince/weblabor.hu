<?php

namespace PHP\Lang;

/**
 * This is a generic parent object for any class
 * @author Janos Pasztor <janos@janoszen.hu>
 * @copyright 2010 Janos Pasztor
 * @license MIT
 */
abstract class Object {
    /**
     * Stores the hash code of the current class. May be empty, use hashCode() instead!
     * @var int
     */
    private $hashCode;

    /**
     * Object constructor
     */
    public function __construct() {
    }

    /**
     * Object destructor
     */
    public function __destruct() {
    }

    /**
     * Returns the name of the current class
     * @return string
     */
    public final function className() {
	return get_class($this);
    }

    /**
     * Returns a unique identifier for the current class
     * @return int
     */
    public function hashCode() {
	if (!$this->hashCode) {
	    $this->hashCode = rand(1, getrandmax());
	}
	return $this->hashCode;
    }

    /**
     * Compares the current class to an other
     * @param self $object
     * @return bool
     */
    public function equals($object) {
	return $object == $this ? true : false;
    }

    /**
     * Converts the current class to a string.
     * @return string
     */
    public function __toString() {
	return $this->className() . "@" . base_convert($this->hashCode(), 10, 16);
    }

    /**
     * Returns if an object is a subclass of an other
     * @param string $class
     * @return bool
     */
    public function isSubclass($class) {
	return is_subclass_of($this, $class);
    }

    /**
     * Returns if an object is an instance of a class
     * @param string $class
     * @return bool
     */
    public function isInstance($class) {
	return ($this instanceof $class? true : false);
    }

    /**
     * Only classes implementing the PHP\Lang\Clonable interface
     * should be cloned.
     * @throws \PHP\Lang\CloneNotSupportedException
     */
    public function __clone() {
	if (!$this->isInstance("\PHP\Lang\Clonable")) {
	    throw new CloneNotSupportedException();
	}
    }

    /**
     * Method to call uppon object serialization. Any class available for
     * serialization should implement the \PHP\IO\Serializable interface.
     *
     * @throws \PHP\IO\NotSerializableException
     */
    public function __sleep() {
	if (!$this->isInstance("\PHP\IO\Serializable"))
	{
	    throw new \PHP\IO\NotSerializableException($this->className());
	}
    }

    /**
     * Method to call uppon object deserialization. Any class available for
     * serialization should implement the \PHP\IO\Serializable interface.
     *
     * @throws \PHP\IO\NotSerializableException
     */
    public function __wakeup() {
	if (!$this->isInstance("\PHP\IO\Serializable"))
	{
	    throw new \PHP\IO\NotSerializableException($this->className());
	}
    }
}