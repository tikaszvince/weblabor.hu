function isPrime( num ) {
	for (var i = 2; i <= Math.sqrt(num); i += 1)
		if (num % i == 0)
			return false;
	return true;
}
var num = 123456789, count = 0, start, end;

start = new Date();
while ( count < 3000 ) { if ( isPrime( ++num ) ) { ++count; } }
end = new Date();
print( (end - start) / 1000.0 + ' (' + num + ')');


