public class prime {
	static boolean isPrime( int num ) {
		for (int i = 2; i <= Math.sqrt(num); i += 1)
			if (num % i == 0)
				return false;
		return true;
	}
	
	public static void main( String[] args ) {
		int count = 0;
		int num = 123456789;
		
		try {
			Thread.sleep(1);
		} catch (Exception e) {};
		
		
		long start = System.currentTimeMillis();
		while ( count < 3000) { if ( isPrime( ++num ) ) { ++count; } }
		long end = System.currentTimeMillis();
		System.out.println( (end - start) / 1000.0 + " (" + num + ")");
	}
};