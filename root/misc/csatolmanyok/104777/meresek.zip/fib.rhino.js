function fibonacci(n) {
	return n <= 1 ? n :
		fibonacci(n-1) + fibonacci(n-2);
};

var start = new Date();
var fib = fibonacci( 35 );
var end = new Date();
print( (end - start)/1000.0 + ' (' + fib + ')' );
