function fibonacci(n) {
	return n <= 1 ? n :
		fibonacci(n-1) + fibonacci(n-2);
};

setTimeout(function() {
	var start = new Date();
	var fib = fibonacci( 35 );
	var end = new Date();
	require('sys').puts( (end - start)/1000.0 + ' (' + fib + ')' );
},1000);