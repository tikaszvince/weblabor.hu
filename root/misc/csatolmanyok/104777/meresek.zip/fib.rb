def fib(n)
	n<=1 ? n : fib(n-1) + fib(n-2)
end

Tstart = Time.now
res = fib(35)
Tend = Time.now
puts  "#{(Tend-Tstart)} (#{res})"
