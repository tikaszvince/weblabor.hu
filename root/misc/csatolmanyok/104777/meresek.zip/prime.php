<?php
function isPrime( $num ) {
	for ( $i = 2; $i <= sqrt($num); $i += 1)
		if ($num % $i == 0)
			return false;
	return true;
}

$num = 123456789;
$count = 0;

sleep(1);

$start = microtime(true);
while ( $count < 3000) { if ( isPrime( ++$num ) ) { ++$count; } }
$end = microtime(true);
print ($end - $start) . ' (' . $num . ')'."\n";
?>