#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>

int fib(const int n)
{
    return n < 2 ? n : fib( n-1 ) + fib( n-2 );
}

double getTime()
{
    struct timeval tv;
    struct tm *tm;
    gettimeofday( &tv, 0 );
    return tv.tv_sec + tv.tv_usec / 1000000.0;
}

int main(int argc, char **argv, char **env)
{
    int res;
    double start;
    double end;
    
    sleep(1);
    start = getTime();
    res = fib( 35 );
    end = getTime();
    printf("%f (%u)\n",end-start,res);
    return 0;
}
