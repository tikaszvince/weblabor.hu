#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>
#include <unistd.h>

int isPrime( const int num )
{
    int i;
    for ( i = 2; i <= sqrt(num); i += 1 )
    if (num % i == 0)
        return 0;
    return 1;
}

double getTime()
{
    struct timeval tv;
    struct tm *tm;
    gettimeofday( &tv, 0 );
    return tv.tv_sec + tv.tv_usec / 1000000.0;
}

int main(int argc, char **argv, char **env)
{
    int num = 123456789;
    int count = 0;
    double start;
    double end;
    
    sleep(1);
    start = getTime();
    while ( count < 3000 ) { if ( isPrime( ++num ) ) { ++count; } }
    end = getTime();
    printf("%f (%u)\n",end-start,num);
    return 0;
}
