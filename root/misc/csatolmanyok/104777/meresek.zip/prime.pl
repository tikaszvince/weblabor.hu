use Time::HiRes qw ( time );

sub isPrime {
	my $num = shift;
	for ( my $i = 2; $i <= sqrt($num); $i += 1) {
		if ($num % $i == 0) {
			return 0;
		}
	}
	return 1;
}

my $num = 123456789;
my $count = 0;

sleep(1);
my $start = time;
while ( $count < 3000) { if ( isPrime( ++$num ) ) { ++$count; } }
$end = time;
print '' . ($end - $start) . ' (' . $num . ')'."\n";
