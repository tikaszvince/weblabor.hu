public class fib {
	static int fibonacci( int num ) {
		return num <= 1 ? num : fibonacci( num - 1 ) + fibonacci( num - 2 );
	}
	public static void main( String[] args ) {
		try {
			Thread.sleep(1);
		} catch (Exception e) {};
		long start = System.currentTimeMillis();
		int res = fibonacci( 35 );
		long end = System.currentTimeMillis();
		System.out.println( (end - start) / 1000.0 + " (" + res + ")");
	}
};