<?php
function fibonacci($n){ 
	return $n <= 1 ? $n : 
		fibonacci($n-1) + fibonacci($n-2);
}

sleep(1);

$start = microtime(true);
$fib = fibonacci( 35 );
$end = microtime(true);
print ($end - $start) . ' (' . $fib . ')'."\n";
?>