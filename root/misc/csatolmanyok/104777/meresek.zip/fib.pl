use Time::HiRes qw ( time );

sub fibonacci {
	my $n = shift;
	return $n <= 1 ? $n :
		fibonacci($n-1) + fibonacci($n-2);
}

sleep(1);

my $start = time;
my $fib = fibonacci( 35 );
my $end = time;
print '' . ($end - $start) . ' (' . $fib . ')' . "\n";